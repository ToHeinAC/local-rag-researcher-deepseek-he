import os
import re
import json
import torch
import requests
from typing import Dict, List, Any, Optional, Union
from langchain.schema import Document
from pydantic import BaseModel, Field
from datetime import datetime
import ollama

# Define the API key environment variable name
TAVILY_API_KEY_ENV = "TAVILY_API_KEY"

# Define the Tavily API endpoint
TAVILY_API_ENDPOINT = "https://api.tavily.com/search"

# Define the OpenRouter API endpoint
OPENROUTER_API_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"

# Define the OpenRouter API key environment variable name
OPENROUTER_API_KEY_ENV = "OPENROUTER_API_KEY"

# Define model classes for structured output
class Queries(BaseModel):
    queries: List[str] = Field(description="List of search queries")

class Evaluation(BaseModel):
    is_relevant: bool = Field(description="Whether the documents are relevant to the query")

class SummaryRankings(BaseModel):
    rankings: List[int] = Field(description="Ranked indices of summaries by relevance")

class SummaryRelevance(BaseModel):
    is_relevant: bool = Field(description="Whether the summary is relevant to the query")

class QualityCheckResult(BaseModel):
    quality_score: float = Field(description="Quality score between 0 and 1")
    is_sufficient: bool = Field(description="Whether the summary contains sufficient information")
    improvement_needed: bool = Field(description="Whether the summary needs improvement")
    improvement_suggestions: str = Field(description="Suggestions for improvement if needed")

def clear_cuda_memory():
    """Clear CUDA memory cache to free up GPU resources."""
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        print("CUDA memory cache cleared")

def tavily_search(query, api_key=None, max_results=5, search_depth="basic"):
    """
    Perform a web search using the Tavily API.
    
    Args:
        query (str): The search query
        api_key (str, optional): Tavily API key. If not provided, will try to get from environment
        max_results (int, optional): Maximum number of results to return. Defaults to 5.
        search_depth (str, optional): Search depth, either "basic" or "advanced". Defaults to "basic".
        
    Returns:
        dict: Search results from Tavily
    """
    # Get API key from environment if not provided
    if not api_key:
        api_key = os.environ.get(TAVILY_API_KEY_ENV)
        if not api_key:
            raise ValueError(f"Tavily API key not provided and not found in environment variable {TAVILY_API_KEY_ENV}")
    
    # Prepare the request payload
    payload = {
        "api_key": api_key,
        "query": query,
        "max_results": max_results,
        "search_depth": search_depth
    }
    
    # Make the request to Tavily API
    response = requests.post(TAVILY_API_ENDPOINT, json=payload)
    
    # Check if the request was successful
    if response.status_code == 200:
        return response.json()
    else:
        raise Exception(f"Tavily API request failed with status code {response.status_code}: {response.text}")

def transform_documents_for_citation(documents):
    """
    Transforms a list of Document objects into a specific dictionary format for citation.
    
    Args:
        documents (list): List of Document objects with metadata and page_content
        
    Returns:
        list: List of dictionaries with content and metadata in the required format
    """
    samples = []
    
    for doc in documents:
        transformed_doc = {
            "content": doc.page_content,
            "metadata": {
                "name": doc.metadata.get('id', doc.metadata.get('source', 'Unknown')),
                "path": doc.metadata.get('source', 'Unknown')
            }
        }
        samples.append(transformed_doc)
    
    return samples

def format_documents_with_metadata(documents, preserve_original=False, enable_citation=False):
    """
    Format documents with metadata for presentation to the LLM.
    
    Args:
        documents: List of Document objects or formatted web search results
        preserve_original: Whether to preserve the original content without modifications
        enable_citation: Whether to enable citation formatting for the LLM
        
    Returns:
        str: Formatted document string
    """
    formatted_docs = []
    
    # Handle both Document objects and web search results (which are already formatted strings)
    if documents and isinstance(documents[0], str):
        return "\n\n".join(documents)
    
    for doc in documents:
        # Get the source filename from metadata
        source = doc.metadata.get('source', 'Unknown source')
        
        # Ensure we have an absolute path to the document
        doc_path = ''
        if 'path' in doc.metadata and os.path.isfile(doc.metadata['path']):
            doc_path = doc.metadata['path']
        elif 'source' in doc.metadata:
            # Try to construct an absolute path to the file in the files directory
            potential_path = os.path.abspath(os.path.join(os.getcwd(), 'files', source))
            if os.path.isfile(potential_path):
                doc_path = potential_path
            else:
                # If file doesn't exist in the current directory structure, still use the path format
                # This ensures consistent citation format even for documents that might be processed later
                doc_path = os.path.abspath(os.path.join(os.getcwd(), 'files', source))
        
        # Extract just the filename for display
        filename = os.path.basename(source) if source != 'Unknown source' else 'Unknown source'
        
        # Get document ID if available
        doc_id = doc.metadata.get('id', filename)
        
        # Format with markdown link using the required format: [Document Name](document_path)
        # Ensure the path includes the /files folder as specified in the updated requirements
        if doc_path:
            # Make sure the path contains the /files directory for consistency
            if '/files/' not in doc_path and '\\files\\' not in doc_path:
                files_dir = os.path.join(os.getcwd(), 'files')
                doc_path = os.path.join(files_dir, filename)
            
            if enable_citation:
                # Use the format from the example notebook: [Document Name](document_path)
                source_link = f"[{doc_id}]({source})"
            else:
                source_link = f"[{filename}]({doc_path})"
        else:
            # If no path is available, still create a standard format with a placeholder path
            files_dir = os.path.join(os.getcwd(), 'files')
            doc_path = os.path.join(files_dir, filename)
            
            if enable_citation:
                # Use the format from the example notebook: [Document Name](document_path)
                source_link = f"[{doc_id}]({source})"
            else:
                source_link = f"[{filename}]({doc_path})"
        
        # When preserve_original is True, include the full original content without any modifications
        if preserve_original:
            formatted_doc = f"SOURCE: {source_link}\n\nContent: {doc.page_content}"
        else:
            formatted_doc = f"SOURCE: {source_link}\n\nContent: {doc.page_content}"
            
        formatted_docs.append(formatted_doc)
    
    return "\n\n".join(formatted_docs)

def format_context_for_citation(context_documents):
    """
    Format context documents for citation in a way that instructs the LLM to cite properly.
    
    Args:
        context_documents: List of Document objects
        
    Returns:
        str: Formatted context string with citation instructions
    """
    formatted_context = "\n".join(
        f"Content: {doc['content']}\nSource: {doc['metadata']['name']}\nPath: {doc['metadata']['path']}"
        for doc in context_documents
    )
    
    return formatted_context

def source_summarizer_with_citation(context_documents, llm_model="deepseek-r1:latest"):
    """
    Summarize source documents with proper citation.
    
    Args:
        context_documents: List of Document objects
        llm_model: LLM model to use for summarization
        
    Returns:
        dict: Dictionary containing the summarized content and metadata
    """
    # Transform documents to the required format
    transformed_docs = transform_documents_for_citation(context_documents)
    
    # Create system message with citation instructions
    system_message = """
    You are an expert summarizer working within a RAG system. Your task is to create a concise, accurate summary of the provided information while properly attributing all facts to their sources.
    
    Guidelines:
    - Create a clear, coherent summary limited to 3-5 sentences
    - Focus on the most important facts and insights
    - Maintain factual accuracy without adding new information
    - Use neutral, professional language
    - Cite EVERY piece of information using the format [Document Name](document_path)
    - Place citations immediately after the relevant information
    - Ensure each citation is correctly matched to its source
    - Return only the plain text summary without markdown formatting
    """
    
    # Format the context for the LLM
    formatted_context = format_context_for_citation(transformed_docs)
    
    # Create the prompt
    prompt = f"""
    Here are the documents to summarize:
    
    {formatted_context}
    
    Provide a concise summary with proper citations:
    """
    
    # Call the LLM
    response = ollama.chat(
        model=llm_model,
        messages=[
            {"role": "system", "content": system_message},
            {"role": "user", "content": prompt}
        ]
    )
    
    response_content = response["message"]["content"]
    
    # Clean markdown formatting if present
    try:
        final_content = re.sub(r"<think>.*?</think>", "", response_content, flags=re.DOTALL).strip()
    except:
        final_content = response_content.strip()
    
    # Extract metadata from all documents
    document_names = [doc['metadata']['name'] for doc in transformed_docs]
    document_paths = [doc['metadata']['path'] for doc in transformed_docs]
    
    return {
        "content": final_content,
        "metadata": {
            "names": document_names,
            "paths": document_paths
        }
    }

def invoke_ollama(model, system_prompt=None, user_prompt=None, output_format=None):
    """
    Invoke Ollama with the given prompts and return the response.
    
    Args:
        model (str): The Ollama model to use
        system_prompt (str, optional): System prompt to use
        user_prompt (str, optional): User prompt to use
        output_format (BaseModel, optional): Pydantic model to parse the output into
        
    Returns:
        str or BaseModel: The response from Ollama, parsed into the output_format if provided
    """
    messages = []
    
    if system_prompt:
        messages.append({"role": "system", "content": system_prompt})
    
    if user_prompt:
        messages.append({"role": "user", "content": user_prompt})
    
    response = ollama.chat(model=model, messages=messages)
    
    if output_format:
        try:
            # Extract the content from the response
            content = response["message"]["content"]
            
            # Try to parse the content as JSON
            try:
                # First, try to find a JSON object in the content
                json_match = re.search(r'```json\s*(.*?)\s*```', content, re.DOTALL)
                if json_match:
                    json_str = json_match.group(1)
                else:
                    # If no JSON code block, try to find a JSON object directly
                    json_match = re.search(r'({.*})', content, re.DOTALL)
                    if json_match:
                        json_str = json_match.group(1)
                    else:
                        # If still no match, use the entire content
                        json_str = content
                
                # Parse the JSON string
                parsed_json = json.loads(json_str)
                
                # Create an instance of the output_format model
                return output_format(**parsed_json)
            except Exception as e:
                print(f"Error parsing JSON: {e}")
                print(f"Content: {content}")
                
                # If JSON parsing fails, try to extract values directly
                if hasattr(output_format, '__annotations__'):
                    result = {}
                    for field_name, field_type in output_format.__annotations__.items():
                        # Try to find the field in the content
                        field_match = re.search(rf'"{field_name}":\s*(.*?)(?:,|\s*}})', content, re.DOTALL)
                        if field_match:
                            field_value = field_match.group(1).strip()
                            
                            # Convert the field value to the appropriate type
                            if field_type == bool:
                                result[field_name] = field_value.lower() == 'true'
                            elif field_type == int:
                                result[field_name] = int(field_value)
                            elif field_type == float:
                                result[field_name] = float(field_value)
                            elif field_type == List[str]:
                                # Try to parse as a list
                                list_match = re.search(r'\[(.*?)\]', field_value, re.DOTALL)
                                if list_match:
                                    items = list_match.group(1).split(',')
                                    result[field_name] = [item.strip().strip('"\'') for item in items]
                                else:
                                    result[field_name] = []
                            else:
                                result[field_name] = field_value.strip('"\'')
                    
                    return output_format(**result)
                else:
                    raise ValueError(f"Failed to parse response into {output_format.__name__}")
        except Exception as e:
            print(f"Error parsing response: {e}")
            raise e
    
    return response

def invoke_llm(model, system_prompt=None, user_prompt=None, output_format=None):
    """
    Invoke an LLM via OpenRouter with the given prompts and return the response.
    
    Args:
        model (str): The model to use (e.g., 'gpt-4o-mini', 'claude-3-opus-20240229', 'deepseek-coder:latest')
        system_prompt (str, optional): System prompt to use
        user_prompt (str, optional): User prompt to use
        output_format (BaseModel, optional): Pydantic model to parse the output into
        
    Returns:
        str or BaseModel: The response from the LLM, parsed into the output_format if provided
    """
    # Get API key from environment
    api_key = os.environ.get(OPENROUTER_API_KEY_ENV)
    if not api_key:
        raise ValueError(f"OpenRouter API key not found in environment variable {OPENROUTER_API_KEY_ENV}")
    
    # Prepare the request payload
    payload = {
        "model": model,
        "messages": []
    }
    
    if system_prompt:
        payload["messages"].append({"role": "system", "content": system_prompt})
    
    if user_prompt:
        payload["messages"].append({"role": "user", "content": user_prompt})
    
    # Make the request to OpenRouter API
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    response = requests.post(OPENROUTER_API_ENDPOINT, headers=headers, json=payload)
    
    # Check if the request was successful
    if response.status_code == 200:
        response_json = response.json()
        content = response_json["choices"][0]["message"]["content"]
        
        if output_format:
            try:
                # Try to parse the content as JSON
                try:
                    # First, try to find a JSON object in the content
                    json_match = re.search(r'```json\s*(.*?)\s*```', content, re.DOTALL)
                    if json_match:
                        json_str = json_match.group(1)
                    else:
                        # If no JSON code block, try to find a JSON object directly
                        json_match = re.search(r'({.*})', content, re.DOTALL)
                        if json_match:
                            json_str = json_match.group(1)
                        else:
                            # If still no match, use the entire content
                            json_str = content
                    
                    # Parse the JSON string
                    parsed_json = json.loads(json_str)
                    
                    # Create an instance of the output_format model
                    return output_format(**parsed_json)
                except Exception as e:
                    print(f"Error parsing JSON: {e}")
                    print(f"Content: {content}")
                    
                    # If JSON parsing fails, try to extract values directly
                    if hasattr(output_format, '__annotations__'):
                        result = {}
                        for field_name, field_type in output_format.__annotations__.items():
                            # Try to find the field in the content
                            field_match = re.search(rf'"{field_name}":\s*(.*?)(?:,|\s*}})', content, re.DOTALL)
                            if field_match:
                                field_value = field_match.group(1).strip()
                                
                                # Convert the field value to the appropriate type
                                if field_type == bool:
                                    result[field_name] = field_value.lower() == 'true'
                                elif field_type == int:
                                    result[field_name] = int(field_value)
                                elif field_type == float:
                                    result[field_name] = float(field_value)
                                elif field_type == List[str]:
                                    # Try to parse as a list
                                    list_match = re.search(r'\[(.*?)\]', field_value, re.DOTALL)
                                    if list_match:
                                        items = list_match.group(1).split(',')
                                        result[field_name] = [item.strip().strip('"\'') for item in items]
                                    else:
                                        result[field_name] = []
                                else:
                                    result[field_name] = field_value.strip('"\'')
                        
                        return output_format(**result)
                    else:
                        raise ValueError(f"Failed to parse response into {output_format.__name__}")
            except Exception as e:
                print(f"Error parsing response: {e}")
                raise e
        
        return {"response": content}
    else:
        raise Exception(f"OpenRouter API request failed with status code {response.status_code}: {response.text}")

def parse_output(response):
    """
    Parse the output from the LLM response.
    
    Args:
        response: The response from the LLM
        
    Returns:
        dict: Dictionary containing the parsed response
    """
    if isinstance(response, dict) and "message" in response and "content" in response["message"]:
        content = response["message"]["content"]
    elif isinstance(response, dict) and "response" in response:
        content = response["response"]
    else:
        content = str(response)
    
    # Clean up the content by removing any thinking sections
    cleaned_content = re.sub(r'<think>.*?</think>', '', content, flags=re.DOTALL).strip()
    
    return {"response": cleaned_content}
