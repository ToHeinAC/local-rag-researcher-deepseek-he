import datetime
from typing_extensions import Literal
from langgraph.constants import Send
from langgraph.graph import START, END, StateGraph
from langchain_core.runnables.config import RunnableConfig
from src.assistant.configuration import Configuration
from src.assistant.vector_db import get_or_create_vector_db, search_documents
from src.assistant.state import ResearcherState, ResearcherStateInput, ResearcherStateOutput, QuerySearchState, QuerySearchStateInput, QuerySearchStateOutput, SummaryRanking
from src.assistant.prompts import RESEARCH_QUERY_WRITER_PROMPT, RELEVANCE_EVALUATOR_PROMPT, SUMMARIZER_PROMPT, REPORT_WRITER_PROMPT, QUALITY_CHECKER_PROMPT, CITATION_SUMMARIZER_PROMPT, CITATION_QUALITY_CHECKER_PROMPT, CITATION_REPORT_WRITER_PROMPT
from src.assistant.utils import format_documents_with_metadata, invoke_llm, invoke_ollama, parse_output, tavily_search, Evaluation, Queries, SummaryRankings, SummaryRelevance, QualityCheckResult, transform_documents_for_citation, format_context_for_citation, source_summarizer_with_citation
import re
import time

# Number of query to process in parallel for each batch
# Change depending on the performance of the system
BATCH_SIZE = 3

def generate_research_queries(state: ResearcherState, config: RunnableConfig):
    print("--- Generating research queries ---")
    user_instructions = state["user_instructions"]
    max_queries = config["configurable"].get("max_search_queries", 3)
    llm_model = config["configurable"].get("llm_model", "deepseek-r1:latest")
    
    query_writer_prompt = RESEARCH_QUERY_WRITER_PROMPT.format(
        max_queries=max_queries,
        date=datetime.datetime.now().strftime("%Y/%m/%d %H:%M")
    )
    
    # Using local Deepseek R1 model with Ollama
    result = invoke_ollama(
        model=llm_model,
        system_prompt=query_writer_prompt,
        user_prompt=f"Generate research queries for this user instruction: {user_instructions}",
        output_format=Queries
    )
    
    # Using external LLM providers with OpenRouter: GPT-4o, Claude, Deepseek R1,... 
    # result = invoke_llm(
    #     model='gpt-4o-mini',
    #     system_prompt=query_writer_prompt,
    #     user_prompt=f"Generate research queries for this user instruction: {user_instructions}",
    #     output_format=Queries
    # )

    return {"research_queries": result.queries}

def search_queries(state: ResearcherState):
    # Kick off the search for each query by calling initiate_query_research
    print("--- Searching queries ---")
    # Get the current processing position from state or initialize to 0
    current_position = state.get("current_position", 0)

    return {"current_position": current_position + BATCH_SIZE}


def check_more_queries(state: ResearcherState) -> Literal["search_queries", "filter_search_summaries"]:
    """Check if there are more queries to process"""
    current_position = state.get("current_position", 0)
    if current_position < len(state["research_queries"]):
        return "search_queries"
    return "filter_search_summaries"

def initiate_query_research(state: ResearcherState):
    # Get the next batch of queries
    queries = state["research_queries"]
    current_position = state["current_position"]
    batch_end = min(current_position, len(queries))
    current_batch = queries[current_position - BATCH_SIZE:batch_end]

    # Return the batch of queries to process
    return [
        Send("search_and_summarize_query", {"query": s})
        for s in current_batch
    ]

def retrieve_rag_documents(state: QuerySearchState):
    """Retrieve documents from the RAG database."""
    print("--- Retrieving documents ---")
    query = state["query"]
    
    # Use the new search_documents function from vector_db.py
    documents = search_documents(query, k=3)
    
    return {"retrieved_documents": documents}

def evaluate_retrieved_documents(state: QuerySearchState, config: RunnableConfig):
    query = state["query"]
    retrieved_documents = state["retrieved_documents"]
    llm_model = config["configurable"].get("llm_model", "deepseek-r1:latest")
    evaluation_prompt = RELEVANCE_EVALUATOR_PROMPT.format(
        query=query,
        documents=format_documents_with_metadata(retrieved_documents)
    )
    
    # Using local Deepseek R1 model with Ollama
    evaluation = invoke_ollama(
        model=llm_model,
        system_prompt=evaluation_prompt,
        user_prompt=f"Evaluate the relevance of the retrieved documents for this query: {query}",
        output_format=Evaluation
    )
    
    # Using external LLM providers with OpenRouter: GPT-4o, Claude, Deepseek R1,... 
    # evaluation = invoke_llm(
    #     model='gpt-4o-mini',
    #     system_prompt=evaluation_prompt,
    #     user_prompt=f"Evaluate the relevance of the retrieved documents for this query: {query}",
    #     output_format=Evaluation
    # )

    return {"are_documents_relevant": evaluation.is_relevant}

def route_research(state: QuerySearchState, config: RunnableConfig) -> Literal["summarize_query_research", "web_research", "__end__"]:
    """ Route the research based on the documents relevance """

    if state["are_documents_relevant"]:
        return "summarize_query_research"
    elif config["configurable"].get("enable_web_search", False):
        return "web_research"
    else:
        print("Skipping query due to irrelevant documents and web search disabled.")
        return "__end__"

def web_research(state: QuerySearchState):
    print("--- Web research ---")
    output = tavily_search(state["query"])
    search_results = output["results"]
    
    # Format web search results to include links
    formatted_results = []
    for result in search_results:
        title = result.get('title', 'Untitled')
        url = result.get('url', '')
        content = result.get('content', '')
        
        # Format as a document with source and link
        formatted_result = f"SOURCE: [{title}]({url})\n\nContent: {content}"
        formatted_results.append(formatted_result)

    return {"web_search_results": formatted_results}

def summarize_query_research(state: QuerySearchState, config: RunnableConfig):
    print("--- Summarizing query research ---")
    query = state["query"]
    llm_model = config["configurable"].get("llm_model", "deepseek-r1:latest")
    enable_citation = config["configurable"].get("enable_citation", True)

    information = None
    if state["are_documents_relevant"]:
        # If documents are relevant: Use RAG documents
        information = state["retrieved_documents"]
    else:
        # If documents are irrelevant: Use web search results,
        # if enabled, otherwise query will be skipped in the previous router node
        information = state["web_search_results"]

    if enable_citation and state["are_documents_relevant"]:
        # Use citation-enabled summarization for RAG documents
        print("Using citation-enabled summarization")
        
        # Transform documents for citation
        transformed_docs = transform_documents_for_citation(information)
        
        # Format context for citation
        formatted_information = format_context_for_citation(transformed_docs)
        
        # Use citation-specific prompt
        summary_prompt = CITATION_SUMMARIZER_PROMPT.format(
            query=query,
            documents=formatted_information
        )
        
        # Using local model with Ollama
        summary = invoke_ollama(
            model=llm_model,
            system_prompt=summary_prompt,
            user_prompt=f"Create a concise summary with proper citations that answers this query: {query}"
        )
        
        # Remove thinking part if present
        summary = parse_output(summary)["response"]
        
        # Store document metadata for verification
        document_names = [doc['metadata']['name'] for doc in transformed_docs]
        document_paths = [doc['metadata']['path'] for doc in transformed_docs]
        
        return {
            "search_summaries": [summary],
            "summary_improvement_iterations": 0,  # Initialize the iteration counter
            "original_summary": summary,  # Store the original summary for reference
            "document_names": document_names,  # Store document names for verification
            "document_paths": document_paths  # Store document paths for verification
        }
    else:
        # Use standard summarization without citation emphasis
        # Format documents with metadata but simplified without emphasis on citations
        # Preserve original content as much as possible
        formatted_information = format_documents_with_metadata(information, preserve_original=True) if state["are_documents_relevant"] else information
        
        summary_prompt = SUMMARIZER_PROMPT.format(
            query=query,
            documents=formatted_information
        )
        
        # Using local model with Ollama
        summary = invoke_ollama(
            model=llm_model,
            system_prompt=summary_prompt,
            user_prompt=f"Extract and include relevant information from the documents that answers this query, preserving original wording: {query}"
        )
        # Remove thinking part if present
        summary = parse_output(summary)["response"]

        return {
            "search_summaries": [summary],
            "summary_improvement_iterations": 0,  # Initialize the iteration counter
            "original_summary": summary  # Store the original summary for reference
        }

def route_after_summarization(state: QuerySearchState, config: RunnableConfig) -> Literal["quality_check_summary", "__end__"]:
    """Route based on whether quality checking is enabled."""
    enable_quality_checker = config["configurable"].get("enable_quality_checker", True)
    
    if enable_quality_checker:
        print("Quality checker is enabled, proceeding to quality check")
        return "quality_check_summary"
    else:
        print("Quality checker is disabled, skipping quality check")
        return "__end__"

def quality_check_summary(state: QuerySearchState, config: RunnableConfig):
    """Simple quality check to ensure the summary contains sufficient information."""
    print("--- Quality checking summary ---")
    query = state["query"]
    current_summary = state["search_summaries"][0]
    llm_model = config["configurable"].get("llm_model", "deepseek-r1:latest")
    quality_check_loops = config["configurable"].get("quality_check_loops", 1)  # Get configured loop count
    enable_citation = config["configurable"].get("enable_citation", True)
    
    # Get the source documents
    information = None
    if state["are_documents_relevant"]:
        information = state["retrieved_documents"]
    else:
        information = state["web_search_results"]
    
    # Format documents with metadata
    formatted_information = format_documents_with_metadata(information) if state["are_documents_relevant"] else information
    
    # Choose the appropriate quality checker prompt based on citation setting
    if enable_citation and state["are_documents_relevant"] and "document_names" in state:
        quality_prompt = CITATION_QUALITY_CHECKER_PROMPT.format(
            summary=current_summary,
            documents=formatted_information
        )
    else:
        quality_prompt = QUALITY_CHECKER_PROMPT.format(
            summary=current_summary,
            documents=formatted_information
        )
    
    try:
        # Initialize quality check results
        quality_check = None
        
        # Perform quality checks in a loop based on configured count
        for i in range(quality_check_loops):
            print(f"Quality check iteration {i+1}/{quality_check_loops}")
            
            # Using local model with Ollama
            quality_check = invoke_ollama(
                model=llm_model,
                system_prompt=quality_prompt,
                user_prompt=f"Evaluate if this summary contains sufficient information to answer the query: {query}",
                output_format=QualityCheckResult
            )
            
            # If the summary is sufficient, break the loop
            if quality_check.is_sufficient:
                print("Summary is sufficient, breaking quality check loop")
                break
            
            # If the summary is not sufficient and we have more iterations to go
            if not quality_check.is_sufficient and i < quality_check_loops - 1:
                print("Summary is not sufficient, improving...")
                
                # Increment the iteration counter
                state["summary_improvement_iterations"] += 1
                
                # Prepare the improvement prompt
                improvement_prompt = f"""
                Your previous summary was not sufficient. Here's the feedback:
                
                {quality_check.improvement_suggestions}
                
                Please improve the summary based on this feedback. Remember to include all relevant information from the source documents.
                
                Original query: {query}
                
                Source documents:
                {formatted_information}
                """
                
                # Using local model with Ollama to improve the summary
                improved_summary = invoke_ollama(
                    model=llm_model,
                    system_prompt=quality_prompt,  # Reuse the same system prompt
                    user_prompt=improvement_prompt
                )
                
                # Update the current summary
                current_summary = parse_output(improved_summary)["response"]
                state["search_summaries"] = [current_summary]
        
        # Return the final quality check result
        return {
            "quality_score": quality_check.quality_score,
            "is_sufficient": quality_check.is_sufficient,
            "improvement_needed": quality_check.improvement_needed,
            "improvement_suggestions": quality_check.improvement_suggestions
        }
    except Exception as e:
        print(f"Error in quality check: {e}")
        # Return a default quality check result in case of error
        return {
            "quality_score": 0.5,
            "is_sufficient": True,  # Assume sufficient to continue the process
            "improvement_needed": False,
            "improvement_suggestions": f"Error in quality check: {str(e)}"
        }

def filter_search_summaries(state: ResearcherState, config: RunnableConfig):
    """Filter and rank search summaries based on relevance to the original query."""
    print("--- Filtering search summaries ---")
    
    # Get all search summaries from the state
    all_summaries = []
    for query_state in state.get("query_states", []):
        if "search_summaries" in query_state and query_state["search_summaries"]:
            # Get the first (and usually only) summary for each query
            summary = query_state["search_summaries"][0]
            all_summaries.append(summary)
    
    # If there are no summaries, return empty rankings
    if not all_summaries:
        return {"summary_rankings": []}
    
    # If there's only one summary, it's automatically the most relevant
    if len(all_summaries) == 1:
        return {"summary_rankings": [0]}
    
    # For multiple summaries, rank them based on relevance to the original query
    user_instructions = state["user_instructions"]
    llm_model = config["configurable"].get("llm_model", "deepseek-r1:latest")
    
    # Format the summaries for ranking
    formatted_summaries = "\n\n".join([f"Summary {i+1}:\n{summary}" for i, summary in enumerate(all_summaries)])
    
    # Create a prompt for ranking the summaries
    ranking_prompt = f"""
    Rank the following summaries based on their relevance to the user's original query.
    
    User query: {user_instructions}
    
    {formatted_summaries}
    
    Respond with a valid JSON object containing a single key "rankings" with an array of indices (0-based) in order of relevance:
    {{"rankings": [most_relevant_index, second_most_relevant_index, ...]}}
    """
    
    try:
        # Using local model with Ollama
        rankings = invoke_ollama(
            model=llm_model,
            system_prompt="You are a helpful assistant that ranks research summaries based on relevance to the original query.",
            user_prompt=ranking_prompt,
            output_format=SummaryRankings
        )
        
        # Ensure all indices are included in the rankings
        all_indices = set(range(len(all_summaries)))
        ranked_indices = set(rankings.rankings)
        missing_indices = all_indices - ranked_indices
        
        # Add any missing indices to the end of the rankings
        complete_rankings = rankings.rankings + list(missing_indices)
        
        return {"summary_rankings": complete_rankings}
    except Exception as e:
        print(f"Error in ranking summaries: {e}")
        # In case of error, return default rankings (in original order)
        return {"summary_rankings": list(range(len(all_summaries)))}

def write_research_report(state: ResearcherState, config: RunnableConfig):
    """Write a comprehensive research report based on the ranked summaries."""
    print("--- Writing research report ---")
    
    # Get the user's original instructions
    user_instructions = state["user_instructions"]
    
    # Get the ranked summaries
    rankings = state.get("summary_rankings", [])
    all_query_states = state.get("query_states", [])
    
    # If there are no rankings or query states, return an empty report
    if not rankings or not all_query_states:
        return {"research_report": "No relevant information found for your query."}
    
    # Collect the ranked summaries and their corresponding queries
    ranked_information = []
    for rank in rankings:
        if rank < len(all_query_states):
            query_state = all_query_states[rank]
            if "search_summaries" in query_state and query_state["search_summaries"]:
                query = query_state.get("query", "Unknown query")
                summary = query_state["search_summaries"][0]
                ranked_information.append(f"Query: {query}\n\nInformation:\n{summary}")
    
    # Combine all the ranked information
    combined_information = "\n\n---\n\n".join(ranked_information)
    
    # Get the report structure from configuration or use a default
    report_structure = config["configurable"].get("report_structure", """
    # Research Report
    
    ## Summary
    
    ## Key Findings
    
    ## Detailed Analysis
    
    ## Conclusion
    """)
    
    # Get the LLM model to use
    llm_model = config["configurable"].get("llm_model", "deepseek-r1:latest")
    enable_citation = config["configurable"].get("enable_citation", True)
    
    # Choose the appropriate report writer prompt based on citation setting
    if enable_citation:
        report_prompt = CITATION_REPORT_WRITER_PROMPT.format(
            instruction=user_instructions,
            report_structure=report_structure,
            information=combined_information
        )
    else:
        report_prompt = REPORT_WRITER_PROMPT.format(
            instruction=user_instructions,
            report_structure=report_structure,
            information=combined_information
        )
    
    # Using local model with Ollama
    report = invoke_ollama(
        model=llm_model,
        system_prompt=report_prompt,
        user_prompt=f"Write a comprehensive research report that addresses this query: {user_instructions}"
    )
    
    # Extract the report content
    report_content = parse_output(report)["response"]
    
    return {"research_report": report_content}

def create_researcher_graph(config: Configuration):
    """Create the researcher workflow graph."""
    
    # Create the main researcher graph
    researcher_graph = StateGraph(ResearcherState)
    
    # Add nodes to the graph
    researcher_graph.add_node("generate_research_queries", generate_research_queries)
    researcher_graph.add_node("search_queries", search_queries)
    researcher_graph.add_node("filter_search_summaries", filter_search_summaries)
    researcher_graph.add_node("write_research_report", write_research_report)
    
    # Add conditional edges
    researcher_graph.add_conditional_edges(
        "search_queries",
        check_more_queries,
        {
            "search_queries": "search_queries",
            "filter_search_summaries": "filter_search_summaries"
        }
    )
    
    # Add regular edges
    researcher_graph.add_edge("generate_research_queries", "search_queries")
    researcher_graph.add_edge("filter_search_summaries", "write_research_report")
    researcher_graph.add_edge("write_research_report", END)
    
    # Set the entry point
    researcher_graph.set_entry_point(START)
    researcher_graph.add_edge(START, "generate_research_queries")
    
    # Create the query search subgraph
    query_search_graph = StateGraph(QuerySearchState)
    
    # Add nodes to the subgraph
    query_search_graph.add_node("retrieve_rag_documents", retrieve_rag_documents)
    query_search_graph.add_node("evaluate_retrieved_documents", evaluate_retrieved_documents)
    query_search_graph.add_node("web_research", web_research)
    query_search_graph.add_node("summarize_query_research", summarize_query_research)
    query_search_graph.add_node("quality_check_summary", quality_check_summary)
    
    # Add conditional edges
    query_search_graph.add_conditional_edges(
        "evaluate_retrieved_documents",
        route_research,
        {
            "summarize_query_research": "summarize_query_research",
            "web_research": "web_research",
            "__end__": END
        }
    )
    
    query_search_graph.add_conditional_edges(
        "summarize_query_research",
        route_after_summarization,
        {
            "quality_check_summary": "quality_check_summary",
            "__end__": END
        }
    )
    
    # Add regular edges
    query_search_graph.add_edge("retrieve_rag_documents", "evaluate_retrieved_documents")
    query_search_graph.add_edge("web_research", "summarize_query_research")
    query_search_graph.add_edge("quality_check_summary", END)
    
    # Set the entry point
    query_search_graph.set_entry_point(START)
    query_search_graph.add_edge(START, "retrieve_rag_documents")
    
    # Compile the subgraph
    query_search_chain = query_search_graph.compile()
    
    # Add the thread for processing individual queries
    researcher_graph.add_thread(
        "search_and_summarize_query",
        initiate_query_research,
        query_search_chain,
        join_results=True
    )
    
    # Compile the main graph
    return researcher_graph.compile()
