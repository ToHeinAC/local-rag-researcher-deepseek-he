# Citation Implementation Documentation

## Overview

This document describes the implementation of source citation functionality in the local ollama RAG agent. The implementation allows the agent to properly cite sources in its responses, following the format `[Document Name](document_path)` as specified in the requirements.

## Files Modified

The following files were modified to implement the citation functionality:

1. `src/assistant/utils.py`
2. `src/assistant/prompts.py`
3. `src/assistant/graph.py`

## Implementation Details

### 1. Document Transformation for Citation

Added new functions in `utils.py` to transform documents for citation:

- `transform_documents_for_citation`: Transforms Document objects into a specific dictionary format with content and metadata for citation.
- `format_context_for_citation`: Formats context for the LLM with citation instructions.
- `source_summarizer_with_citation`: Summarizes sources with proper citation.

Example of document transformation:
```python
def transform_documents_for_citation(documents):
    """
    Transforms a list of Document objects into a specific dictionary format for citation.
    
    Args:
        documents (list): List of Document objects with metadata and page_content
        
    Returns:
        list: List of dictionaries with content and metadata in the required format
    """
    samples = []
    
    for doc in documents:
        transformed_doc = {
            "content": doc.page_content,
            "metadata": {
                "name": doc.metadata.get('id', doc.metadata.get('source', 'Unknown')),
                "path": doc.metadata.get('source', 'Unknown')
            }
        }
        samples.append(transformed_doc)
    
    return samples
```

### 2. Citation Formatting

Enhanced the existing `format_documents_with_metadata` function in `utils.py` to support citation formatting:

```python
def format_documents_with_metadata(documents, preserve_original=False, enable_citation=False):
    # ...
    if enable_citation:
        # Use the format from the example notebook: [Document Name](document_path)
        source_link = f"[{doc_id}]({source})"
    else:
        source_link = f"[{filename}]({doc_path})"
    # ...
```

### 3. Citation Prompt Templates

Added new prompt templates in `prompts.py` to instruct the LLM to cite sources properly:

- `CITATION_SUMMARIZER_PROMPT`: Instructions for summarizing with citations
- `CITATION_QUALITY_CHECKER_PROMPT`: Quality checking with citation verification
- `CITATION_REPORT_WRITER_PROMPT`: Report writing with citation requirements

Example of citation prompt:
```python
CITATION_SUMMARIZER_PROMPT="""You are an expert summarizer working within a RAG system. Your task is to create a concise, accurate summary of the provided information while properly attributing all facts to their sources.

Query: {query}

Documents:
{documents}

Guidelines:
- Create a clear, coherent summary that directly answers the query
- Focus on the most important facts and insights
- Maintain factual accuracy without adding new information
- Use neutral, professional language
- Cite EVERY piece of information using the format [Document Name](document_path)
- Place citations immediately after the relevant information
- Ensure each citation is correctly matched to its source
- Include exact levels, figures, numbers, statistics, and quantitative data ONLY from the source Documents
- Preserve section or paragraph references from the original Documents when available
- Use direct quotes for key definitions and important statements
- Maintain precise numerical values, ranges, percentages, or measurements
"""
```

### 4. Workflow Integration

Modified the workflow in `graph.py` to integrate citation functionality:

- Updated `summarize_query_research` to use citation-enabled summarization when appropriate
- Added a configuration option `enable_citation` to control citation functionality
- Enhanced `quality_check_summary` to verify citation quality
- Updated `write_research_report` to support citations

Example of workflow integration:
```python
def summarize_query_research(state: QuerySearchState, config: RunnableConfig):
    # ...
    enable_citation = config["configurable"].get("enable_citation", True)

    if enable_citation and state["are_documents_relevant"]:
        # Use citation-enabled summarization for RAG documents
        print("Using citation-enabled summarization")
        
        # Transform documents for citation
        transformed_docs = transform_documents_for_citation(information)
        
        # Format context for citation
        formatted_information = format_context_for_citation(transformed_docs)
        
        # Use citation-specific prompt
        summary_prompt = CITATION_SUMMARIZER_PROMPT.format(
            query=query,
            documents=formatted_information
        )
        
        # Using local model with Ollama
        summary = invoke_ollama(
            model=llm_model,
            system_prompt=summary_prompt,
            user_prompt=f"Create a concise summary with proper citations that answers this query: {query}"
        )
        
        # Store document metadata for verification
        document_names = [doc['metadata']['name'] for doc in transformed_docs]
        document_paths = [doc['metadata']['path'] for doc in transformed_docs]
        
        return {
            "search_summaries": [summary],
            "summary_improvement_iterations": 0,
            "original_summary": summary,
            "document_names": document_names,
            "document_paths": document_paths
        }
    else:
        # Use standard summarization without citation emphasis
        # ...
```

## Testing

The citation functionality was tested using a simplified test script that verified:

1. Document transformation for citation
2. Context formatting for the LLM
3. Document metadata formatting with citation options

All tests passed successfully, confirming that the implementation correctly formats documents for citation using the `[Document Name](document_path)` format.

## Usage

To enable citation in the RAG agent, set the `enable_citation` configuration option to `True` (it's enabled by default):

```python
config = {
    "configurable": {
        "enable_citation": True,
        # other configuration options...
    }
}
```

When citation is enabled, the agent will:

1. Transform documents to include metadata for citation
2. Format prompts to instruct the LLM to cite sources
3. Include citations in the generated summaries and reports
4. Verify citation quality during quality checking

## Conclusion

The implementation successfully adds source citation functionality to the local ollama RAG agent, following the requirements specified in the example notebook. The citation format `[Document Name](document_path)` is consistently applied throughout the system, ensuring that all information is properly attributed to its source.
